package edu.mum.cs.cs425.elibrary.eLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ELibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
