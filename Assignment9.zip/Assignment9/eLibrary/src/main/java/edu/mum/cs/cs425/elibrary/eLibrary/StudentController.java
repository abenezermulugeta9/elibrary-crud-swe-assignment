package edu.mum.cs.cs425.elibrary.eLibrary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/eregistrar")
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;

    // Handle displaying the homepage
    @GetMapping("/home")
    public String showHomePage() {
        return "home";
    }

    // Handle displaying a list of students
    @GetMapping("/students")
    public String listStudents(Model model) {
        List<Student> students = studentRepository.findAll();
        model.addAttribute("students", students);
        return "list";
    }

    // Handle registering a new student
    @GetMapping("/students/new")
    public String showRegistrationForm(Model model) {
        model.addAttribute("student", new Student());
        return "registration-form";
    }

    @PostMapping("/students/new")
    public String registerStudent(@ModelAttribute("student") Student student) {
        studentRepository.save(student);
        return "redirect:/eregistrar/students";
    }

    // Handle editing student data
    @GetMapping("/students/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        Student student = studentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid student ID"));
        model.addAttribute("student", student);
        return "edit-form";
    }

    @PostMapping("/students/edit/{id}")
    public String editStudent(@PathVariable("id") Long id, @ModelAttribute("student") Student student) {
        student.setId(id);
        studentRepository.save(student);
        return "redirect:/eregistrar/students";
    }

    // Handle deleting a student
    @GetMapping("/students/delete/{id}")
    public String deleteStudent(@PathVariable("id") Long id) {
        studentRepository.deleteById(id);
        return "redirect:/eregistrar/students";
    }

    @GetMapping("/students/search-form")
    public String searchForm(Model model) {
        model.addAttribute("student", new Student());
        return "search-form";
    }

    @PostMapping("/students/search")
    public String searchStudents(
            @RequestParam(name = "studentNumber", required = false) String studentNumber,
            @RequestParam(name = "firstName", required = false) String firstName,
            // Add parameters for other search criteria here
            Model model) {

        List<Student> matchingStudents = new ArrayList<>();

        if (studentNumber != null && !studentNumber.isEmpty()) {
            matchingStudents.addAll(studentRepository.findByStudentNumber(studentNumber));
        }

        if (firstName != null && !firstName.isEmpty()) {
            matchingStudents.addAll(studentRepository.findByFirstName(firstName));
        }

        // Add similar logic for other search criteria if needed

        model.addAttribute("students", matchingStudents);
        return "search-results"; // Create this Thymeleaf template
    }
}
